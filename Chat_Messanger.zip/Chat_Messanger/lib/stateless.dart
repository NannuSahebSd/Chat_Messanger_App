import 'package:flutter/material.dart';
class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  List pages =[
    "🏠 Home Page",
    "🔍 Search page",
    "📹 Reels page",
    "Ⓜ️ Message page"
  ];
  int _selectedIndex = 0;
  void onTapPages(int index){
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        backgroundColor: Colors.pink,
        leading: Icon(Icons.mail),
        title:Text(
          "Simple App",
          style:TextStyle(
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
          ) ,
          ),
          actions: [
            Icon(Icons.search),
            SizedBox(width:20),
            Icon(Icons.menu),
            SizedBox(width:20),
          ],
      ) ,
      body:Center(
        child:Text(
          pages[_selectedIndex],
          style: TextStyle(fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic),
        ),
      ),
      bottomNavigationBar:BottomNavigationBar(
        backgroundColor: Colors.brown,
        items: [BottomNavigationBarItem(
            icon:Icon(Icons.home),
            label:"home",
            backgroundColor: Colors.brown,
            ),
            BottomNavigationBarItem(
            icon:Icon(Icons.search),
            label:"Search",
            backgroundColor: Colors.brown,
            ),
            BottomNavigationBarItem(
            icon:Icon(Icons.movie_filter),
            label:"Reels",
            backgroundColor: Colors.brown,
            ),
            BottomNavigationBarItem(
            icon:Icon(Icons.message),
            label:"message",
            backgroundColor: Colors.brown,
            ),
            ],
            ),
    );
  }
}