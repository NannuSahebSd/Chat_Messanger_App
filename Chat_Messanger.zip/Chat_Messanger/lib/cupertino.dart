import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
void main(){
  runApp(CupertinoApp(
    home: Scaffold(
      body: Center(
        child: Text(
          "hello Flutter",
          style: TextStyle(
            fontSize: 30.5,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
          ),
        ),
      ),
    ),
  )
  );
}