import 'package:flutter/material.dart';

class HomePage extends StatelessWidget{
const HomePage({super.key});
@override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        leading:Icon(Icons.notifications),
        title:Text(
          "RVIT",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
          ),
        ),
        actions: [
          Icon(Icons.person_4_rounded,color:Colors.black ),
          SizedBox(width: 20.5),
          Icon(Icons.menu,color:Colors.black),
          SizedBox(width:20.5),
        ],
        bottom:PreferredSize(
          preferredSize:Size(200,50),
        child:Padding(
          padding:const EdgeInsets.fromLTRB(20,0,20,0),
          child: TextField(
            decoration: InputDecoration(
              fillColor: Colors.white38,
              filled:true,
              prefixIcon:Icon(Icons.search,color:Colors.white),
              labelText:"Search...",
              labelStyle: TextStyle(color: Colors.white,
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic,
              ),
            ),
          ),
        ),
      ),
      ),
      body:Center(
        child:Text(
          "My Simple App",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            fontSize: 30.5,
          ),
      ),
      ),
      bottomNavigationBar: BottomNavigationBar( 
        currentIndex: 2,
        backgroundColor: Colors.brown,
        items: [
          BottomNavigationBarItem(
            icon:Icon(Icons.home),
            label:"Home",
            backgroundColor:Colors.brown,
          ),
          BottomNavigationBarItem(
            icon:Icon(Icons.search),
            label:"Search",
            backgroundColor: Colors.brown,
            ),
            BottomNavigationBarItem(
            icon:Icon(Icons.movie_filter),
            label:"Reels",
            backgroundColor: Colors.brown,
            ),
            BottomNavigationBarItem(
            icon:Icon(Icons.message_outlined),
            label:"Message",
            backgroundColor: Colors.brown,
            ),
        ],
  ),
    );
  }
}