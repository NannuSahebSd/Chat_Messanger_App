import "package:flutter/material.dart";

void main() {
  runApp(
    MaterialApp(debugShowCheckedModeBanner: false, home: FlutterButtons()),
  );
}

class FlutterButtons extends StatelessWidget {
  const FlutterButtons({super.key});

  void searchIconFun() {
    print("User clicked on search icon");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: Text(
          "Types of Buttons",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
          ),
        ),
        actions: [
          IconButton(
            onPressed: searchIconFun,
            icon: Icon(Icons.search, color: Colors.white),
          ),

          IconButton(
            onPressed: () {
              print("User clicked on profile icon");
            },
            icon: Icon(Icons.person_2_rounded, color: Colors.white),
          ),
          IconButton(
            onPressed: () {
              print("User clicked on settings icon");
            },
            icon: Icon(Icons.settings, color: Colors.white),
          ),
        ],
      ),

      body: Center(
        child: Column(
          children: [
            ElevatedButton(
              style: ButtonStyle(backgroundColor: WidgetStateColor.transparent),
              onPressed: () {
                for (var i = 1; i <= 5; i++) {
                  print(i);
                }
              },
              child: Text("Click "),
            ),

            FilledButton(
              onPressed: () {
                print("Profile Page");
              },
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(50),
                  child: Image.network(
                    "https://t3.ftcdn.net/jpg/02/43/12/34/360_F_243123463_zTooub557xEWABDLk0jJklDyLSGl2jrr.jpg",
                    width: 100,
                    height: 100,
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ),

            TextButton(
              onPressed: () {
                print("Text button");
              },
              child: Text("Text Button"),
            ),

            SizedBox(height: 50),

            OutlinedButton(
              onPressed: () {
                print("user clicked");
              },
              onHover: (bool val) {
                print(val);
                print("hello");
              },
              child: Text("Outline Text"),
            ),
          ],
        ),
      ),
    );
  }
}

class StackExample extends StatelessWidget {
  const StackExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text(
          "Stack Example",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          Icon(Icons.menu),
          SizedBox(width: 30),
          SizedBox(width: 60, child: Text("Profile")),
        ],
      ),

      body: Center(
        child: Stack(
          alignment: AlignmentDirectional.bottomCenter,
          children: [
            Container(
              height: 200,
              width: 200,
              decoration: BoxDecoration(color: Colors.orange),
            ),

            Container(
              height: 150,
              width: 150,
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 0, 255, 8),
              ),
            ),

            Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 255, 0, 221),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SizedBoxExample extends StatelessWidget {
  const SizedBoxExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text("Sized Box", style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          Icon(Icons.menu),
          SizedBox(width: 30),
          SizedBox(width: 60, child: Text("Profile")),
        ],
      ),
      body: Center(
        child: Container(
          decoration: BoxDecoration(color: Colors.brown),
          child: SizedBox(
            height: 200,
            width: 200,
            child: Text(
              "Sample Sized Box",
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class RowWidgetExample extends StatelessWidget {
  const RowWidgetExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,

        title: Text(
          "Row Widget",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
          ),
        ),

        actions: [
          Icon(Icons.notifications),
          SizedBox(width: 20),
          Icon(Icons.person),
          SizedBox(width: 25),
        ],
        bottom: PreferredSize(
          preferredSize: Size(200, 50),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.search),
                fillColor: Colors.white60,
                label: Text("Search"),
                filled: true,
              ),
            ),
          ),
        ),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 90,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.asset(
                      "assets/images/rvit_logo.jpg",
                      height: 50,
                      width: 50,
                    ),
                  ),

                  Column(
                    children: [
                      Text(
                        "RVIT ",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 21,
                          fontStyle: FontStyle.italic,
                          decoration: TextDecoration.underline,
                          decorationThickness: 3,
                        ),
                      ),
                      Text("College Code :HU "),
                      Text("Branch :AIML "),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              height: 90,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.asset(
                      "assets/images/rvit_logo.jpg",
                      height: 50,
                      width: 50,
                    ),
                  ),

                  Column(
                    children: [
                      Text(
                        "RVIT ",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 21,
                          fontStyle: FontStyle.italic,
                          decoration: TextDecoration.underline,
                          decorationThickness: 3,
                        ),
                      ),
                      Text("College Code :HU "),
                      Text("Branch :AIML "),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              height: 90,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.asset(
                      "assets/images/rvit_logo.jpg",
                      height: 50,
                      width: 50,
                    ),
                  ),

                  Column(
                    children: [
                      Text(
                        "RVIT ",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 21,
                          fontStyle: FontStyle.italic,
                          decoration: TextDecoration.underline,
                          decorationThickness: 3,
                        ),
                      ),
                      Text("College Code :HU "),
                      Text("Branch :AIML "),
                    ],
                  ),
                ],
              ),
            ),

            Container(
              height: 90,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.asset(
                      "assets/images/rvit_logo.jpg",
                      height: 50,
                      width: 50,
                    ),
                  ),

                  Column(
                    children: [
                      Text(
                        "RVIT ",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 21,
                          fontStyle: FontStyle.italic,
                          decoration: TextDecoration.underline,
                          decorationThickness: 3,
                        ),
                      ),
                      Text("College Code :HU "),
                      Text("Branch :AIML "),
                    ],
                  ),
                ],
              ),
            ),

            Container(
              height: 90,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.asset(
                      "assets/images/rvit_logo.jpg",
                      height: 50,
                      width: 50,
                    ),
                  ),

                  Column(
                    children: [
                      Text(
                        "RVIT ",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 21,
                          fontStyle: FontStyle.italic,
                          decoration: TextDecoration.underline,
                          decorationThickness: 3,
                        ),
                      ),
                      Text("College Code :HU "),
                      Text("Branch :AIML "),
                    ],
                  ),
                ],
              ),
            ),

            Container(
              height: 90,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.asset(
                      "assets/images/rvit_logo.jpg",
                      height: 50,
                      width: 50,
                    ),
                  ),

                  Column(
                    children: [
                      Text(
                        "RVIT ",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 21,
                          fontStyle: FontStyle.italic,
                          decoration: TextDecoration.underline,
                          decorationThickness: 3,
                        ),
                      ),
                      Text("College Code :HU "),
                      Text("Branch :AIML "),
                    ],
                  ),
                ],
              ),
            ),

            Container(
              height: 90,
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.asset(
                      "assets/images/rvit_logo.jpg",
                      height: 50,
                      width: 50,
                    ),
                  ),

                  Column(
                    children: [
                      Text(
                        "RVIT ",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 21,
                          fontStyle: FontStyle.italic,
                          decoration: TextDecoration.underline,
                          decorationThickness: 3,
                        ),
                      ),
                      Text("College Code :HU "),
                      Text("Branch :AIML "),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ColumnWidgetExample extends StatelessWidget {
  const ColumnWidgetExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,

        title: Text(
          "Column Widget",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
          ),
        ),

        actions: [
          Icon(Icons.notifications),
          SizedBox(width: 20),
          Icon(Icons.person),
          SizedBox(width: 25),
        ],
        bottom: PreferredSize(
          preferredSize: Size(200, 50),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.search),
                fillColor: Colors.white60,
                label: Text("Search"),
                filled: true,
              ),
            ),
          ),
        ),
      ),

      body: Center(
        child: Container(
          margin: EdgeInsets.all(20),
          padding: EdgeInsets.all(20),
          height: 400,
          width: 500,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),

            color: Colors.deepOrangeAccent,
          ),
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(8, 5),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.asset(
                    "assets/images/rvit_logo.jpg",
                    height: 150,
                    width: 150,
                  ),
                ),
              ),
              SizedBox(height: 20),
              Text(
                "RV Institute Of Technology",
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  fontStyle: FontStyle.italic,
                ),
              ),

              Text("College :HU", style: TextStyle(fontSize: 25)),
              Text("Address: Gunter , Ap..", style: TextStyle(fontSize: 25)),
              Text(
                "Department : AMIL, CSE , DS",
                style: TextStyle(fontSize: 25),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//Container
class LayOutWidget extends StatelessWidget {
  const LayOutWidget({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.greenAccent,
        title: Text(
          "Layout Widgets Example",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
          ),
        ),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.settings)),
          IconButton(onPressed: () {}, icon: Icon(Icons.more_vert)),
        ],
      ),

      body: Center(
        child: Container(
          height: 90,
          width: 450,
          // margin: EdgeInsets.fromLTRB(10, 50, 10, 90),
          // padding: EdgeInsets.all(50),
          decoration: BoxDecoration(
            color: Colors.redAccent,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(0),
              bottom: Radius.circular(50),
            ),
            border: Border.all(color: Colors.green, width: 5),

            boxShadow: [
              BoxShadow(
                color: Colors.black,
                offset: Offset(15, 15),
                blurRadius: 20,
              ),
              BoxShadow(
                color: Colors.blue,
                offset: Offset(6, 6),
                blurRadius: 10,
              ),
            ],
          ),

          child: Center(child: Text("offers", style: TextStyle(fontSize: 20))),
        ),
      ),
    );
  }
}