import 'package:flutter/material.dart';

import '../models/user.dart';

class GroupChatScreen extends StatefulWidget {
  @override
  _GroupChatScreenState createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final List<User> _selectedContacts = [];
  final _groupNameController = TextEditingController();
  final List<User> _allContacts = [
    User(id: '1', name: 'Nataraj', email: 'nataraj@example.com', avatarUrl: ''),
    User(id: '2', name: 'Varma', email: 'varma@example.com', avatarUrl: ''),
    User(id: '3', name: 'Arjun', email: 'arjun@example.com', avatarUrl: ''),
    User(id: '4', name: 'Pavan', email: 'pavan@example.com', avatarUrl: ''),
  ];

  void _toggleContact(User contact) {
    setState(() {
      if (_selectedContacts.contains(contact)) {
        _selectedContacts.remove(contact);
      } else {
        _selectedContacts.add(contact);
      }
    });
  }

  void _createGroup() {
    if (_groupNameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter group name')),
      );
      return;
    }

    if (_selectedContacts.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please select at least 2 members')),
      );
      return;
    }

    // Navigate to group chat
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('New Group'),
        actions: [
          IconButton(
            icon: Icon(Icons.check),
            onPressed: _createGroup,
          ),
        ],
      ),
      body: Column(
        children: [
          // Group Name Input
          Padding(
            padding: EdgeInsets.all(16),
            child: TextField(
              controller: _groupNameController,
              decoration: InputDecoration(
                labelText: 'Group Name',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          // Selected Contacts
          if (_selectedContacts.isNotEmpty)
            Container(
              height: 80,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _selectedContacts.length,
                itemBuilder: (ctx, index) {
                  final contact = _selectedContacts[index];
                  return Padding(
                    padding: EdgeInsets.all(8),
                    child: Column(
                      children: [
                        Stack(
                          children: [
                            _buildSafeAvatar(contact.avatarUrl, contact.name, 20),
                            Positioned(
                              right: 0,
                              child: GestureDetector(
                                onTap: () => _toggleContact(contact),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.red,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(Icons.close, size: 16, color: Colors.white),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Text(contact.name, style: TextStyle(fontSize: 12)),
                      ],
                    ),
                  );
                },
              ),
            ),
          Divider(),
          // Contacts List
          Expanded(
            child: ListView.builder(
              itemCount: _allContacts.length,
              itemBuilder: (ctx, index) {
                final contact = _allContacts[index];
                final isSelected = _selectedContacts.contains(contact);
                
                return ListTile(
                  leading: _buildSafeAvatar(contact.avatarUrl, contact.name, 40),
                  title: Text(contact.name),
                  subtitle: Text(contact.email),
                  trailing: Checkbox(
                    value: isSelected,
                    onChanged: (_) => _toggleContact(contact),
                  ),
                  onTap: () => _toggleContact(contact),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSafeAvatar(String avatarUrl, String name, double radius) {
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';
    return CircleAvatar(
      radius: radius,
      backgroundColor: Colors.blue[100],
      child: Text(
        initials,
        style: TextStyle(
          color: Colors.blue[800],
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
} 