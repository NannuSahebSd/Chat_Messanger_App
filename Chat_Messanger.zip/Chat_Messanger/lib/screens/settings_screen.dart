import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: ListView(
        children: [
          // Account Settings
          _buildSectionHeader('Account'),
          _buildSettingsTile(
            Icons.person,
            'Account',
            'Privacy, security, change number',
            Icons.chevron_right,
          ),
          _buildSettingsTile(
            Icons.chat,
            'Chats',
            'Theme, wallpapers, chat history',
            Icons.chevron_right,
          ),
          _buildSettingsTile(
            Icons.notifications,
            'Notifications',
            'Message, group & call tones',
            Icons.chevron_right,
          ),
          _buildSettingsTile(
            Icons.data_usage,
            'Storage and Data',
            'Network usage, auto-download',
            Icons.chevron_right,
          ),
          Divider(),
          // Support
          _buildSectionHeader('Support'),
          _buildSettingsTile(
            Icons.help,
            'Help',
            'Help center, contact us, privacy policy',
            Icons.chevron_right,
          ),
          _buildSettingsTile(
            Icons.group,
            'Invite a Friend',
            'Share the app with your friends',
            Icons.share,
          ),
          Divider(),
          // About
          _buildSectionHeader('About'),
          _buildSettingsTile(
            Icons.info,
            'About',
            'Version 1.0.0',
            Icons.chevron_right,
          ),
          SizedBox(height: 20),
          // App Version
          Center(
            child: Text(
              'Chat Messenger v1.0.0',
              style: TextStyle(
                color: Colors.grey,
              ),
            ),
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.grey[600],
        ),
      ),
    );
  }

  Widget _buildSettingsTile(
    IconData icon,
    String title,
    String subtitle,
    IconData trailingIcon,
  ) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: Icon(trailingIcon),
      onTap: () {
        // Handle tap
      },
    );
  }
}