import 'package:flutter/material.dart';

import '../models/user.dart';

class ChatDetailScreen extends StatelessWidget {
  const ChatDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final User contact = ModalRoute.of(context)!.settings.arguments as User;

    return Scaffold(
      appBar: AppBar(
        title:const Text('Chat Info'),
      ),
      body: ListView(
        children: [
          // Header Section
          Container(
            padding:const EdgeInsets.all(20),
            color: Colors.white,
            child: Column(
              children: [
                _buildSafeAvatar(contact.avatarUrl, contact.name, 60),
              const SizedBox(height: 16),
                Text(
                  contact.name,
                  style:const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              const  SizedBox(height: 8),
                Text(
                  contact.email,
                  style:const TextStyle(
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
        const Divider(),
          // Media Section
          ListTile(
            leading:const Icon(Icons.photo_library, color: Colors.blue),
            title:const Text('Media, Links & Docs'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image:const DecorationImage(
                      image: AssetImage('assets/images/DOCUMENT.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              const SizedBox(width: 4),
              const  Text('12'),
              ],
            ),
            onTap: () {
              // Navigate to media screen
            },
          ),
        const  Divider(),
          // Options
          _buildOptionTile(Icons.notifications, 'Mute Notifications', true),
          _buildOptionTile(Icons.wallpaper, 'Wallpaper & Sound', false),
          _buildOptionTile(Icons.lock, 'Encryption', false),
        const  Divider(),
          // More Options
          _buildOptionTile(Icons.people, 'Group Members', false),
          _buildOptionTile(Icons.report, 'Report Contact', false),
          _buildOptionTile(Icons.block, 'Block Contact', false),
        const Divider(),
          // Danger Zone
          ListTile(
            leading:const Icon(Icons.delete, color: Colors.red),
            title:const Text(
              'Delete Chat',
              style: TextStyle(color: Colors.red),
            ),
            onTap: () {
              _showDeleteDialog(context);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildOptionTile(IconData icon, String title, bool hasSwitch) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      trailing: hasSwitch
          ? Switch(
              value: false,
              onChanged: (value) {},
            )
          :const Icon(Icons.chevron_right),
      onTap: () {},
    );
  }

  Widget _buildSafeAvatar(String avatarUrl, String name, double radius) {
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';
    return CircleAvatar(
      radius: radius,
      backgroundColor: Colors.blue[100],
      child: Text(
        initials,
        style: TextStyle(
          color: Colors.blue[800],
          fontWeight: FontWeight.bold,
          fontSize: radius * 0.6,
        ),
      ),
    );
  }

  void _showDeleteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title:const Text('Delete Chat'),
        content:const Text('Are you sure you want to delete this chat? All messages will be lost.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child:const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child:const Text(
              'Delete',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}