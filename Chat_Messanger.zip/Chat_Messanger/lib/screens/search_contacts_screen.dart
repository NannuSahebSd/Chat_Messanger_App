import 'package:flutter/material.dart';
import '../models/user.dart';

class SearchContactsScreen extends StatefulWidget {
  @override
  _SearchContactsScreenState createState() => _SearchContactsScreenState();
}

class _SearchContactsScreenState extends State<SearchContactsScreen> {
  final List<User> _allContacts = [
    User(id: '1', name: 'Nataraj', email: 'nataraj@example.com', avatarUrl: ''),
    User(id: '2', name: 'Varma', email: 'varma@example.com', avatarUrl: ''),
    User(id: '3', name: 'Arjun', email: 'arjun@example.com', avatarUrl: ''),
    User(id: '4', name: 'Pavan', email: 'pavan@example.com', avatarUrl: ''),
    User(id: '5', name: 'Venkatesh', email: 'venkatesh@example.com', avatarUrl: ''),
  ];

  List<User> _filteredContacts = [];
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _filteredContacts = _allContacts;
    _searchController.addListener(_searchContacts);
  }

  void _searchContacts() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredContacts = _allContacts.where((contact) {
        return contact.name.toLowerCase().contains(query) ||
               contact.email.toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search Contacts'),
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search contacts...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
              ),
            ),
          ),
          // Results
          Expanded(
            child: _filteredContacts.isEmpty
                ? Center(
                    child: Text(
                      'No contacts found',
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    itemCount: _filteredContacts.length,
                    itemBuilder: (ctx, index) {
                      final contact = _filteredContacts[index];
                      return ListTile(
                        leading: _buildSafeAvatar(contact.avatarUrl, contact.name, 40),
                        title: Text(contact.name),
                        subtitle: Text(contact.email),
                        trailing: IconButton(
                          icon: Icon(Icons.chat, color: Colors.blue),
                          onPressed: () {
                            Navigator.pushNamed(
                              context,
                              '/chat',
                              arguments: contact,
                            );
                          },
                        ),
                        onTap: () {
                          Navigator.pushNamed(
                            context,
                            '/chat',
                            arguments: contact,
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildSafeAvatar(String avatarUrl, String name, double radius) {
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';
    return CircleAvatar(
      radius: radius,
      backgroundColor: Colors.blue[100],
      child: Text(
        initials,
        style: TextStyle(
          color: Colors.blue[800],
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
