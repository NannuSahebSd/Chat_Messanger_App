class User {
  final String id;
  final String name;
  final String email;
  final String status;
  final bool isOnline;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.status = 'Available',
    this.isOnline = false,
  });
}