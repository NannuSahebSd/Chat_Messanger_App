import 'package:flutter/material.dart';

import '../models/message.dart';
import '../models/user.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  List<Message> messages = [];
  final _controller = TextEditingController();
  final _scrollController = ScrollController();

  void sendMessage(String text, User user) {
    if (text.trim().isEmpty) return;
    final message = Message(
      id: DateTime.now().toString(),
      senderId: 'me',
      text: text,
      timestamp: DateTime.now(),
      messageType: MessageType.text,
    );
    setState(() {
      messages.insert(0, message);
    });
    _controller.clear();
    _scrollToBottom();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        0,
        duration:const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _showMediaOptions() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        height: 200,
        child: Column(
          children: [
            ListTile(
              leading:const Icon(Icons.photo),
              title:const Text('Photo & Video Library'),
              onTap: () {
                Navigator.pop(context);
                // Implement photo/video picker
              },
            ),
            ListTile(
              leading:const Icon(Icons.camera_alt),
              title:const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                // Implement camera
              },
            ),
            ListTile(
              leading:const Icon(Icons.attach_file),
              title:const Text('Document'),
              onTap: () {
                Navigator.pop(context);
                // Implement document picker
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final User contact = ModalRoute.of(context)!.settings.arguments as User;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            _buildSafeAvatar(contact.avatarUrl, contact.name, 30),
          const  SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(contact.name),
              const  Text(
                  'Online',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon:const Icon(Icons.videocam),
            onPressed: () {},
          ),
          IconButton(
            icon:const Icon(Icons.call),
            onPressed: () {},
          ),
          IconButton(
            icon:const Icon(Icons.more_vert),
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/chat_detail',
                arguments: contact,
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              reverse: true,
              itemCount: messages.length,
              itemBuilder: (ctx, index) {
                final message = messages[index];
                final isMe = message.senderId == 'me';
                return _buildMessageBubble(message, isMe);
              },
            ),
          ),
          _buildMessageInput(contact),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Message message, bool isMe) {
    return Container(
      margin:const EdgeInsets.symmetric(vertical: 4, horizontal: 16),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe) _buildSafeAvatar('', 'User', 30),
          Flexible(
            child: Container(
              margin:const EdgeInsets.symmetric(horizontal: 8),
              padding:const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isMe ? Colors.blue : Colors.grey[300],
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.text,
                    style: TextStyle(
                      color: isMe ? Colors.white : Colors.black,
                    ),
                  ),
                 const SizedBox(height: 4),
                  Text(
                    _formatTime(message.timestamp),
                    style: TextStyle(
                      fontSize: 10,
                      color: isMe ? Colors.white70 : Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isMe) _buildSafeAvatar('', 'Me', 30),
        ],
      ),
    );
  }

  Widget _buildMessageInput(User contact) {
    return Container(
      padding:const EdgeInsets.all(8),
      decoration:const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            offset: Offset(0, -2),
            blurRadius: 4,
            color: Colors.black12,
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon:const Icon(Icons.add),
            onPressed: _showMediaOptions,
          ),
          Expanded(
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                hintText: 'Type a message...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[100],
                contentPadding:const EdgeInsets.symmetric(horizontal: 16),
              ),
              onSubmitted: (text) => sendMessage(text, contact),
            ),
          ),
          IconButton(
            icon:const Icon(Icons.send),
            onPressed: () => sendMessage(_controller.text, contact),
          ),
        ],
      ),
    );
  }

  Widget _buildSafeAvatar(String avatarUrl, String name, double radius) {
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';
    return CircleAvatar(
      radius: radius,
      backgroundColor: Colors.blue[100],
      child: Text(
        initials,
        style: TextStyle(
          color: Colors.blue[800],
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _formatTime(DateTime timestamp) {
    return '${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0')}';
  }
}