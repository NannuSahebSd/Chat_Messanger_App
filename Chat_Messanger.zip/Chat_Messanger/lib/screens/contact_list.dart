import 'package:flutter/material.dart';
import '../models/user.dart';
import '../models/chat.dart';

class ContactListScreen extends StatelessWidget {
  final List<User> contacts = [
    User(id: '1', name: 'Nataraj', email: 'nataraj@example.com', avatarUrl: 'assets/images/Screenshot_20250318_044753.jpg'),
    User(id: '2', name: 'Varma', email: 'varma@example.com', avatarUrl: 'assets/images/varma_avatar.jpg'),
    User(id: '3', name: 'Arjun', email: 'arjun@example.com', avatarUrl: 'assets/images/arjun_avatar.jpg'),
    User(id: '4', name: 'Pavan', email: 'pavan@example.com', avatarUrl: 'assets/images/pavan_avatar.jpg'),
    User(id: '5', name: 'Venkatesh', email: 'venkatesh@example.com', avatarUrl: 'assets/images/venkatesh_avatar.jpg'),
    User(id: '6', name: 'Prenith', email: 'prenith@example.com', avatarUrl: 'assets/images/prenith_avatar.webp'),
    User(id: '7', name: 'Lokesh', email: 'lokesh@example.com', avatarUrl: 'assets/images/lokesh_avatar.jpg'),
    User(id: '8', name: 'Koti', email: 'koti@example.com', avatarUrl: 'assets/images/koti_avatar.jpg'),
    User(id: '9', name: 'Vinay', email: 'vinay@example.com', avatarUrl: 'assets/images/vinay_avatar.jpg'),
  ];

  final List<Chat> recentChats = [
    Chat(
      id: '1',
      name: 'Nataraj',
      lastMessage: 'Hey, how are you?',
      timestamp: DateTime.now().subtract(Duration(minutes: 5)),
      unreadCount: 2,
      isGroup: false,
    ),
    Chat(
      id: '2',
      name: 'Flutter Team',
      lastMessage: 'Meeting at 3 PM today',
      timestamp: DateTime.now().subtract(Duration(hours: 1)),
      unreadCount: 5,
      isGroup: true,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chats'),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              Navigator.pushNamed(context, '/search');
            },
          ),
          IconButton(
            icon: Icon(Icons.group_add),
            onPressed: () {
              Navigator.pushNamed(context, '/group_chat');
            },
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'profile') {
                Navigator.pushNamed(context, '/profile');
              } else if (value == 'settings') {
                Navigator.pushNamed(context, '/settings');
              }
            },
            itemBuilder: (BuildContext context) => [
              PopupMenuItem(value: 'profile', child: Text('Profile')),
              PopupMenuItem(value: 'settings', child: Text('Settings')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Recent Chats Section
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Recent Chats',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton(
                  onPressed: () {
                    // View all chats
                  },
                  child: Text('View All'),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: recentChats.length,
              itemBuilder: (ctx, index) {
                final chat = recentChats[index];
                return Container(
                  width: 80,
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.blue[100],
                        child: chat.isGroup 
                            ? Icon(Icons.group, color: Colors.blue)
                            : Text(
                                chat.name[0],
                                style: TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        chat.name,
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 12),
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (chat.unreadCount > 0)
                        Container(
                          padding: EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            chat.unreadCount.toString(),
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
          Divider(),
          // Contacts Section
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Contacts',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text('${contacts.length} contacts'),
              ],
            ),
          ),
          Expanded(
            flex: 5,
            child: ListView.builder(
              itemCount: contacts.length,
              itemBuilder: (ctx, index) {
                final contact = contacts[index];
                
                return ListTile(
                  leading: _buildSafeAvatar(contact.avatarUrl, contact.name),
                  title: Text(contact.name),
                  subtitle: Text(contact.email),
                  trailing: IconButton(
                    icon: Icon(Icons.chat, color: Colors.blue),
                    onPressed: () {
                      Navigator.pushNamed(
                        context, 
                        '/chat',
                        arguments: contact,
                      );
                    },
                  ),
                  onTap: () {
                    Navigator.pushNamed(
                      context, 
                      '/chat',
                      arguments: contact,
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/search');
        },
        child: Icon(Icons.chat),
      ),
    );
  }

  Widget _buildSafeAvatar(String avatarUrl, String name) {
    try {
      final assetImage = AssetImage(avatarUrl);
      return CircleAvatar(
        backgroundColor: Colors.grey[300],
        backgroundImage: assetImage,
        child: _buildAvatarFallback(name),
      );
    } catch (e) {
      print('❌ ASSET NOT FOUND: $avatarUrl');
      return _buildFallbackAvatar(name);
    }
  }

  Widget _buildFallbackAvatar(String name) {
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';
    return CircleAvatar(
      backgroundColor: Colors.blue[100],
      child: Text(
        initials,
        style: TextStyle(
          color: Colors.blue[800],
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildAvatarFallback(String name) {
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';
    return Text(
      initials,
      style: TextStyle(
        color: Colors.grey[600],
        fontWeight: FontWeight.bold,
      ),
    );
  }
}