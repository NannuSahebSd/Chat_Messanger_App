import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: ListView(
        children: [
          // Profile Header
          Container(
            padding: const EdgeInsets.all(20),
            color: Colors.white,
            child: Column(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundImage:
                      const AssetImage('assets/images/nannu_avatar.jpg'),
                  backgroundColor: Colors.blue[100],
                  onBackgroundImageError: (exception, stackTrace) {
                    debugPrint('Error loading profile image: $exception');
                  },
                ),
                const SizedBox(height: 16),
                const Text(
                  'Nannu Saheb',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'nannusahebsd@gmail.com',
                  style: TextStyle(
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 16),
                OutlinedButton(
                  onPressed: () {
                    // Edit profile action
                  },
                  child: const Text('Edit Profile'),
                ),
              ],
            ),
          ),
          const Divider(),

          // Account Settings
          _buildSectionHeader('Account'),
          _buildProfileTile(Icons.phone, 'Phone', '+91 9392094446'),
          _buildProfileTile(Icons.email, 'Email', 'nannusahebsd@gmail.com'),
          _buildProfileTile(Icons.info, 'Bio', 'Hello! I am using Chat Messenger'),
          const Divider(),

          // Settings
          _buildSectionHeader('Settings'),
          _buildSettingsTile(Icons.notifications, 'Notifications', true),
          _buildSettingsTile(Icons.lock, 'Privacy', false),
          _buildSettingsTile(Icons.security, 'Security', false),
          const Divider(),

          // About
          _buildSectionHeader('About'),
          _buildAboutTile(Icons.star, 'Rate App'),
          _buildAboutTile(Icons.share, 'Share App'),
          _buildAboutTile(Icons.help, 'Help & Support'),
          _buildAboutTile(Icons.privacy_tip, 'Privacy Policy'),
          const SizedBox(height: 20),

          // Logout Button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: ElevatedButton(
              onPressed: () {
                _showLogoutDialog(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Logout'),
            ),
          ),
        ],
      ),
    );
  }

  // Section Header
  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.grey[600],
        ),
      ),
    );
  }

  // Profile Details Tile
  Widget _buildProfileTile(IconData icon, String title, String subtitle) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.edit, color: Colors.grey),
      onTap: () {
        // Add edit logic here
      },
    );
  }

  // Settings Tile (with optional switch)
  Widget _buildSettingsTile(IconData icon, String title, bool hasSwitch) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      trailing: hasSwitch
          ? Switch(
              value: true,
              onChanged: (value) {},
            )
          : const Icon(Icons.chevron_right),
      onTap: () {},
    );
  }

  // About Section Tile
  Widget _buildAboutTile(IconData icon, String title) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      trailing: const Icon(Icons.chevron_right),
      onTap: () {},
    );
  }

  // Logout Confirmation Dialog
  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.popUntil(context, (route) => route.isFirst);
              Navigator.pushReplacementNamed(context, '/login');
            },
            child: const Text(
              'Logout',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}
