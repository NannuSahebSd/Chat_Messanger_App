import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/contact_list.dart';
import 'screens/chat_screen.dart';
import 'screens/chat_detail_screen.dart';
import 'screens/group_chat_screen.dart';
import 'screens/search_contacts_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/settings_screen.dart';


void main() {
  runApp(ChatMessengerApp());
}

class ChatMessengerApp extends StatelessWidget {
  const ChatMessengerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,
      title: 'Chat Messenger',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/splash',
      routes: {
        '/splash': (context) => SplashScreen(),
        '/login': (context) => LoginScreen(),
        '/signup': (context) => SignupScreen(),
        '/contacts': (context) => ContactListScreen(),
        '/chat': (context) => ChatScreen(),
        '/chat_detail': (context) => ChatDetailScreen(),
        '/group_chat': (context) => GroupChatScreen(),
        '/search': (context) => SearchContactsScreen(),
        '/profile': (context) => ProfileScreen(),
        '/settings': (context) => SettingsScreen(),
      },
    );
  }
}
