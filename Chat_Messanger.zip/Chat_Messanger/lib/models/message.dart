enum MessageType {
  text,
  image,
  video,
  document,
}

class Message {
  final String id;
  final String senderId;
  final String text;
  final DateTime timestamp;
  final MessageType messageType;
  final String? mediaUrl;

  Message({
    required this.id,
    required this.senderId,
    required this.text,
    required this.timestamp,
    this.messageType = MessageType.text,
    this.mediaUrl,
  });
}
