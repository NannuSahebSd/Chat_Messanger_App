class Contact {
  final String id;
  final String name;
  final String? profileImage;
  final String status;
  final bool isOnline;

  Contact({
    required this.id,
    required this.name,
    this.profileImage,
    this.status = 'Hey there! I am using Student Chat',
    this.isOnline = false,
  });
}